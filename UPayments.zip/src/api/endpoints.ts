export const BASE_URL = 'https://62286b649fd6174ca82321f1.mockapi.io/case-study/';

export const GET_PRODUCTS = BASE_URL + 'products';
export const GET_PRODUCT_BYID = BASE_URL + 'products/';
export const SAVE_PRODUCT = BASE_URL + 'products';
export const GET_CATEGORIES = BASE_URL + 'categories';
export const GET_CATEGORY_BYID= BASE_URL + 'categories/';

