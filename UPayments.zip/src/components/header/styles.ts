import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
title:{
  fontSize: 22,
  fontWeight: 'bold',
  color: '#000',
},

});
export default styles;
