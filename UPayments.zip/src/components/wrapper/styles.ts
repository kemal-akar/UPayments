import { height, width } from '../../constants'
import { StyleSheet } from 'react-native'

const styles = StyleSheet.create({
  wrapper: {
    width: width, height: height, flexDirection: 'column', flex:1,
    paddingHorizontal:10,justifyContent: 'center',alignContent: 'flex-start',


  },

});
export default styles;
