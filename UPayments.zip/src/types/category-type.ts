export default interface ICategory {
  id?: any | null;
  name: string;
}
