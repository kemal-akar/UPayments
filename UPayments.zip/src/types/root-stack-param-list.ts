export type RootStackParamList = {
  Home: string;
  Detail: string;
  Create: string;
};
